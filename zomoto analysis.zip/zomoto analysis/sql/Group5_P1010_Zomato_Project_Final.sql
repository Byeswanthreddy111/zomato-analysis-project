CREATE DATABASE IF NOT EXISTS ZomatoDB;

USE ZomatoDB;

DROP TABLE IF EXISTS Zomato_Data;
DROP TABLE IF EXISTS Zomato_CountryCode;
DROP TABLE IF EXISTS Zomato_CountryMap;
DROP TABLE IF EXISTS Zomato_DateKey;

SET SQL_SAFE_UPDATES = 0;

CREATE TABLE Zomato_Data (
    RestaurantID INT,
    RestaurantName VARCHAR(255),
    CountryCode INT,
    Country VARCHAR(100),
    City VARCHAR(100),
    Address VARCHAR(255),
    Locality VARCHAR(255),
    LocalityVerbose VARCHAR(255),
    Longitude FLOAT,
    Latitude FLOAT,
    Cuisines VARCHAR(255),
    Currency VARCHAR(50),
    Has_Table_booking VARCHAR(10),
    Has_Online_delivery VARCHAR(10),
    Is_delivering_now VARCHAR(10),
    Switch_to_order_menu VARCHAR(10),
    Price_range INT,
    Votes INT,
    Average_Cost_for_two FLOAT,
    Rating FLOAT,
    Datekey_Opening VARCHAR(20)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE Zomato_CountryCode (
    CountryID INT,
    CountryName VARCHAR(100)
);

CREATE TABLE Zomato_CountryMap (
    Country VARCHAR(100),
    City VARCHAR(100),
    RestaurantID INT,
    RestaurantName VARCHAR(255),
    Count INT
);

CREATE TABLE Zomato_DateKey (
    DateKey VARCHAR(20),
    Year INT,
    MonthNo INT,
    MonthFullName VARCHAR(50),
    Quarter VARCHAR(10),
    YearMonth VARCHAR(20),
    WeekdayNo INT,
    WeekdayName VARCHAR(20),
    FinancialMonth VARCHAR(20),
    FinancialQuarter VARCHAR(10)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Zomato_Data.csv'
INTO TABLE Zomato_Data
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

ALTER TABLE Zomato_Data ADD COLUMN Datekey_Opening_converted DATE;

UPDATE Zomato_Data
SET Datekey_Opening_converted = STR_TO_DATE(Datekey_Opening, '%d/%m/%Y');

ALTER TABLE Zomato_Data DROP COLUMN Datekey_Opening;
ALTER TABLE Zomato_Data CHANGE Datekey_Opening_converted Datekey_Opening DATE;

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Zomato_CountryCode.csv'
INTO TABLE Zomato_CountryCode
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Zomato_CountryMap.csv'
INTO TABLE Zomato_CountryMap
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Zomato_DateKey.csv'
INTO TABLE Zomato_DateKey
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

ALTER TABLE Zomato_DateKey ADD COLUMN DateKey_converted DATE;

UPDATE Zomato_DateKey
SET DateKey_converted = STR_TO_DATE(DateKey, '%d/%m/%Y');

ALTER TABLE Zomato_DateKey DROP COLUMN DateKey;
ALTER TABLE Zomato_DateKey CHANGE DateKey_converted DateKey DATE;

SELECT * FROM Zomato_Data;

SELECT * FROM Zomato_CountryMap;

SELECT * FROM Zomato_CountryCode;

SELECT * FROM Zomato_DateKey

-- Number of Restaurants by City and Country

Select	Country, City, COUNT(RestaurantID) AS Total_Restaurants
FROM Zomato_Data
GROUP BY Country, City
ORDER BY Total_Restaurants DESC;

-- Restaurants Opened by Year, Quarter, Month

SELECT 
    d.Year,
    d.Quarter,
    d.MonthFullName,
    d.MonthNo,
    COUNT(DISTINCT z.RestaurantID) AS Total_Restaurants
FROM Zomato_Data z
JOIN Zomato_DateKey d
    ON z.Datekey_Opening = d.DateKey
GROUP BY d.Year, d.Quarter, d.MonthFullName, d.MonthNo
ORDER BY d.Year, d.MonthNo;

-- Count of Restaurants by Average Rating

SELECT Rating, COUNT(*) AS Restaurant_Count
FROM Zomato_Data
WHERE Rating IS NOT NULL
GROUP BY Rating
ORDER BY Rating DESC;

-- Price Range Buckets

SELECT 
    CASE 
        WHEN Average_Cost_for_two < 500 THEN 'Below 500'
        WHEN Average_Cost_for_two BETWEEN 500 AND 1000 THEN '500–1000'
        WHEN Average_Cost_for_two BETWEEN 1001 AND 2000 THEN '1001–2000'
        WHEN Average_Cost_for_two BETWEEN 2001 AND 4000 THEN '2001–4000'
        ELSE '4000+'
    END AS Price_Bucket,
    COUNT(*) AS Restaurant_Count
FROM Zomato_Data
GROUP BY Price_Bucket
ORDER BY MIN(Average_Cost_for_two);

-- % Restaurants with Table Booking

SELECT 
    Has_Table_booking,
    COUNT(*) AS Count_Restaurants,
    ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM Zomato_Data)), 2) AS Percentage
FROM Zomato_Data
GROUP BY Has_Table_booking;

-- % Restaurants with Online Delivery

SELECT 
    Has_Online_delivery,
    COUNT(*) AS Count_Restaurants,
    ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM Zomato_Data)), 2) AS Percentage
FROM Zomato_Data
GROUP BY Has_Online_delivery;



